import { createServer, Model, Response } from "miragejs";

createServer({
  models: {
    video: Model,
    channel: Model,
    user: Model,
  },

  seeds(server) {
    server.schema.videos.create({
      id: "1",
      channel: "Gronkh",
      icon: "/images/channel.jpg",
      subscribers: 221000,
      comments: {
        0: {
          by: { name: "Maria", id: 2 },
          comment: "Nice Video!",
          date: "2026-01-13 17:24:14.545454",
          likes: 0,
        },
        1: {
          by: { name: "Phandrel", id: 3 },
          comment: "I would have done the overall lightning better",
          date: "2025-11-04 17:24:14.545454",
          likes: 255,
        },
      },
      "date-uploaded": "2025-09-30 13:27:00.595882",
      description: [
        "• ALLE Folgen unter:    • Waterpark Simulator",
        "• Selber spielen: https://s.team/a/3293260",
        "• Mehr Infos zum Game beim Aufklappen 👇",
        "",
        "····················································································",
        "",
        "🎮 WATERPARK SIMULATOR 🎮",
        "",
        "Baue und betreibe deinen eigenen Wasserpark. Entwerfe Rutschen, lasse Gäste mit der Ragdoll-Physik fliegen, verwalte das Personal und passe deinen Park vollständig an. Verwandel den totalen Wahnsinn in ein Fünf-Sterne-Imperium in diesem Management-Simulator in der ersten Person!",
        "",
        "Genre: Gelegenheitsspiele, Indie, Simulationen, Early Access",
        "Entwickler: CayPlay",
        "Publisher: CayPlay",
        "",
        "#Gronkh #Gaming #WaterparkSimulator",
        "····················································································",
        "",
        "🤝 TRANSPARENZ / PRODUCT PLACEMENTS",
        "Deal: − // Reise: − // sonstiges: −",
        "",
        "Mein Hardware-Partner:",
        "• Handgefertigte Gronkh Gaming PCs: https://go.1up.mg/Gronkh-Boostboxx",
        "",
        "Alle mit * versehenen Links sind sogenannte Ref-ID-Links. Das heißt, wenn Du da was kaufst (muss natürlich niemand), dann verdient der Verlinkende (in dem Fall hier also ich) ein paar Cent daran, ohne dass es Dich mehr kostet. Als Beispiel verdient dann Amazon ein klein bisschen weniger am Produkt.",
        "",
        "····················································································",
        "",
        "📺 CHANNELS",
        "  / @gronkh   •    / @gronkhreacts   •    / @bestofgronkh ",
        " / @gronkhretro   •    / @gronkhrpgs   •    / @gronkhosts  ",
        "",
        "🎥 STREAMS",
        "http://gronkh.live (Live)",
        "http://gronkh.tv (VODs)",
        "",
        "🔗 SOCIAL & CO",
        "http://gronkh.chat (Discord)",
        "https://gronkh.shop",
        "",
        "····················································································",
      ],
      likes: 20,
      title:
        "Zu Hause bleiben ist hygienischer als dieses Drecksloch! 🏊 #1 • WATERPARK SIMULATOR",
      url: "/videos/videoplayback.mp4",
      thumb: "/images/wpthumb.avif",
      tags: "Waterpark Simulator, Lets Play",
      views: 50,
    });
    server.schema.channels.create({
      id: "1",
      abonnements: null,
      about: "Yet antoher encrytion test",
      "logo URL": "X0ugL8blb0Qvg1oyVq.jpg",
      name: "Gronkh",
      icon: "/images/channel.jpg",
      playlists: null,
      videos: {
        0: {
          channel: "Gronkh",
          comments: {},
          "date-uploaded": "2025-11-04 17:24:14.545454",
          thumb: "/images/wpthumb.avif",
          description: "Holdrio",
          likes: 0,
          title:
            "Zu Hause bleiben ist hygienischer als dieses Drecksloch! 🏊 #1 • WATERPARK SIMULATOR",
          url: "./uploads/GjZOzXMI.mp4",
          views: 50,
        },
      },
    });
    server.create("user", {
      id: "1",
      email: "user@example.com",
      icon: "/images/channel.jpg",
      password: "p123",
      name: "Gronkh",
    });
  },

  routes() {
    this.namespace = "api";
    this.logging = false;
    this.timing = 2000;

    this.get("/video/:id", (schema, request) => {
      const id = request.params.id;
      //return new Response(400, {}, { error: "Error fetching data" });
      return schema.videos.find(id);
    });

    this.get("/channel/:id", (schema, request) => {
      const id = request.params.id;
      return schema.channels.find(id);
    });

    this.post("/login", (schema, request) => {
      const { email, password } = JSON.parse(request.requestBody);
      // ⚠️ This is an extremely naive version of authentication. Please don't
      // do this in the real world, and never save raw text passwords
      // in your database 😅
      const foundUser = schema.users.findBy({ email, password });
      if (!foundUser) {
        return new Response(
          401,
          {},
          {
            message:
              "No user found, either your email or your password are not correct.",
          }
        );
      }

      // At the very least, don't send the password back to the client 😅
      foundUser.password = undefined;
      return {
        user: foundUser,
        token: "Enjoy your pizza, here's your tokens.",
      };
    });
  },
});
