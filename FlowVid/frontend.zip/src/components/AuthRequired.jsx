import React from "react";
import { Outlet, Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/useAuth";

export default function AuthRequired() {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  return isAuthenticated ? (
    <Outlet />
  ) : (
    <Navigate
      to="/login"
      state={{
        message: "You must log in first",
        from: `${location.pathname}${location.search}`,
      }}
      replace
    />
  );
}
